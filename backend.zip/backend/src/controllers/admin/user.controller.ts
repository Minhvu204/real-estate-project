import { Request, Response } from "express";
import { successResponse, errorResponse } from "../../utils/responseHandler";
import * as userService from "../../services/admin/user.service";

export const getAllUsers = async (req: any, res: Response) => {
  try {
    const { role, page = 1, limit = 10 } = req.query;
    const data = await userService.getAllUsers(
      role,
      Number(page),
      Number(limit)
    );
    return successResponse(res, "Lấy danh sách người dùng thành công", data);
  } catch (error) {
    return errorResponse(res, "Lấy danh sách người dùng thất bại", 500);
  }
};

// [U007] Cập nhật / khóa người dùng (Admin)
export const updateUserStatus = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { isActive } = req.body;

    // Kiểm tra quyền (đảm bảo chỉ admin mới gọi được API này)
    if (req.user?.role !== "admin") {
      return errorResponse(res, "Bạn không có quyền thực hiện thao tác này.", 403);
    }

    // Gọi service để cập nhật trạng thái
    const updatedUser = await userService.updateUserStatus(id, isActive);

    return successResponse(
      res,
      `Cập nhật trạng thái người dùng thành công: ${updatedUser.fullName}`,
      updatedUser
    );
  } catch (error: any) {
    console.error("updateUserStatus error:", error.message);
    return errorResponse(
      res,
      error.message || "Không thể cập nhật trạng thái người dùng.",
      error.status || 500
    );
  }
};